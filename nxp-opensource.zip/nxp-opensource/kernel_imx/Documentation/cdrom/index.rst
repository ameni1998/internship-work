.. SPDX-License-Identifier: GPL-2.0

=====
cdrom
=====

.. toctree::
    :maxdepth: 1

    cdrom-standard
    ide-cd
    packet-writing

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
