.. SPDX-License-Identifier: GPL-2.0

================
Power Management
================

.. toctree::
   :maxdepth: 2

   strategies
   system-wide
   working-state
