.. SPDX-License-Identifier: GPL-2.0

==============================
Working-State Power Management
==============================

.. toctree::
   :maxdepth: 2

   cpuidle
   cpufreq
   intel_pstate
   intel_epb
