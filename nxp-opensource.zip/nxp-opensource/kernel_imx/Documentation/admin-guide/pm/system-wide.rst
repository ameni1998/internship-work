.. SPDX-License-Identifier: GPL-2.0

============================
System-Wide Power Management
============================

.. toctree::
   :maxdepth: 2

   sleep-states
