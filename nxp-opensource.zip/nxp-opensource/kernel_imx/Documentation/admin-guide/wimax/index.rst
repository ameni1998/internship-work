.. SPDX-License-Identifier: GPL-2.0

===============
WiMAX subsystem
===============

.. toctree::
   :maxdepth: 2

   wimax

   i2400m

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
