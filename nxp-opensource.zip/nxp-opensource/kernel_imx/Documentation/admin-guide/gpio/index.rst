.. SPDX-License-Identifier: GPL-2.0

====
gpio
====

.. toctree::
    :maxdepth: 1

    sysfs

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
